@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.unican.es/ss/Service/")
package es.unican.ss.Service;
