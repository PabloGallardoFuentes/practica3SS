package es.unican.ss.Service;

import javax.xml.ws.WebFault;

@WebFault(name = "datosNoValidos", targetNamespace = "http://www.unican.es/ss/Service")
public class DatosNoDisponiblesException extends Exception {
	/**
     * Java type that goes as soapenv:Fault detail element.
     * 
     */
    private String faultInfo;

    /**
     * 
     * @param faultInfo
     * @param message
     */
    public DatosNoDisponiblesException(String message, String faultInfo) {
        super(message);
        this.faultInfo = faultInfo;
    }

    /**
     * 
     * @param faultInfo
     * @param cause
     * @param message
     */
    public DatosNoDisponiblesException(String message, String faultInfo, Throwable cause) {
        super(message, cause);
        this.faultInfo = faultInfo;
    }

    /**
     * 
     * @return
     *     returns fault bean: java.lang.String
     */
    public String getFaultInfo() {
        return faultInfo;
    }
}
