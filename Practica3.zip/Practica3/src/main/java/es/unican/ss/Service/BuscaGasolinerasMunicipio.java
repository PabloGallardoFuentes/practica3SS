package es.unican.ss.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import javax.jws.WebService;

import es.unican.ss.Peticiones.Gasolinera;
import es.unican.ss.Peticiones.Peticiones;

@WebService(targetNamespace = "http://www.unican.es/ss/Service/",
		endpointInterface = "es.unican.ss.Service.IBuscaGasolineraMunicipio",
		serviceName = "BuscaGasolineraService")
public class BuscaGasolinerasMunicipio implements IBuscaGasolinerasMunicipio{

	public BuscaGasolinerasMunicipio() {}
	
	@Override
	public List<Gasolinera> buscaGasolinerasDeGasolina(String municipio) {
		String id = Peticiones.getIDMunicipio(municipio);
		List<Gasolinera> gasolinerasMunicipio = Peticiones.getGasolinerasMunicipio(id);
		
		return buscaMejores5Gasolina95E5(gasolinerasMunicipio);
	}

	@Override
	public List<Gasolinera> buscaGasolinerasDeGasoleo(String municipio) {
		String id = Peticiones.getIDMunicipio(municipio);
		List<Gasolinera> gasolinerasMunicipio = Peticiones.getGasolinerasMunicipio(id);

		return buscaMejores5GasoleoA(gasolinerasMunicipio);
	}
	
	private List<Gasolinera> buscaMejores5GasoleoA(List<Gasolinera> gasolinerasMunicipio) {
		gasolinerasMunicipio.sort(Comparator.comparingDouble(Gasolinera::getPrecioGasoleoA));
		return gasolinerasMunicipio.subList(0, Math.min(5, gasolinerasMunicipio.size()));
	}

	private List<Gasolinera> buscaMejores5Gasolina95E5(List<Gasolinera> gasolinerasMunicipio) {
		gasolinerasMunicipio.sort(Comparator.comparingDouble(Gasolinera::getPrecioGasolina95E5));
		return gasolinerasMunicipio.subList(0, Math.min(5, gasolinerasMunicipio.size()));
	}

}
