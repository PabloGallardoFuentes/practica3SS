package es.unican.ss.Peticiones;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

//@JsonPropertyOrder({"Municipio", "idmunicipio"})
@JsonIgnoreProperties({"IDProvincia", "IDCCAA", "Provincia", "CCAA"})
public class Municipio {
	@JsonProperty("Municipio")
	private String Municipio;
	@JsonProperty("IDMunicipio")
	private String idmunicipio;
	
	
	public String getMunicipio() {
		return Municipio;
	}
	public void setMunicipio(String municipio) {
		Municipio = municipio;
	}
	public String getIDMunicipio() {
		return idmunicipio;
	}
	public void setIDMunicipio(String iDMunicipio) {
		idmunicipio = iDMunicipio;
	}
}
