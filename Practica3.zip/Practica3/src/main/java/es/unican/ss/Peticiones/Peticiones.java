package es.unican.ss.Peticiones;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import es.unican.ss.Peticiones.EurosToString.NumberConversion;
import es.unican.ss.Peticiones.EurosToString.NumberConversionSoapType;

public class Peticiones {
	public static String getIDMunicipio(String municipio) {
		List<Municipio> listado = new ArrayList<Municipio>();
		try {
			// Abrimos la conexión
			URL url = new URL("https://sedeaplicaciones.minetur.gob.es/ServiciosRESTCarburantes/PreciosCarburantes/Listados/Municipios/");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			// Configuramos la invocación
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			// Enviamos la petición y comprobamos la respuesta
			if (conn.getResponseCode() != 200) {
				System.out.println("Failed : HTTP error code : " + conn.getResponseCode());
			}
			else {
				InputStream response = conn.getInputStream();
				

				ObjectMapper mapper = new ObjectMapper();
				listado = mapper.readValue(response, new TypeReference<List<Municipio>>() {});
				
				
				
			}
			conn.disconnect(); // Cerramos la conexión
		} catch (IOException e ) {
			e.printStackTrace();
		}
		
		return buscaIDMunicipioPorNombre(listado, municipio);
	}
	
	/**
	 * 
	 * @param listado
	 * @param municipio
	 * @return el id del municipio pasado como parametro o null
	 */
	private static String buscaIDMunicipioPorNombre(List<Municipio> listado, String municipio) {
		String id = null;
		Iterator<Municipio> iter = listado.iterator();
		
		while(id == null && iter.hasNext()) {
			Municipio m = iter.next();
			
			if(municipio.equals(m.getMunicipio())) {
				id = m.getIDMunicipio();
			}
		}
		
		return id;
	}


	
	public static List<Gasolinera> getGasolinerasMunicipio(String id) {
		List<Gasolinera> listado = new ArrayList<Gasolinera>();
		try {
			// Abrimos la conexión
			URL url = new URL("https://sedeaplicaciones.minetur.gob.es/ServiciosRESTCarburantes/PreciosCarburantes/EstacionesTerrestres/FiltroMunicipio/"
					+ id);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			// Configuramos la invocación
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			// Enviamos la petición y comprobamos la respuesta
			if (conn.getResponseCode() != 200) {
				System.out.println("Failed : HTTP error code : " + conn.getResponseCode());
			}
			else {
				InputStream response = conn.getInputStream();
				
				
				/**BufferedReader br = new BufferedReader(new InputStreamReader(response));
				String output;
				while ((output = br.readLine()) != null) { System.out.println(output);}
				*/
				ObjectMapper mapper = new ObjectMapper();
				JsonNode root = mapper.readTree(response);
				JsonNode listaGasolinerasJson = root.get("ListaEESSPrecio");
				listado = generaGasolineras(listaGasolinerasJson);
				
				
				//listado = mapper.readValue(response, new TypeReference<List<Gasolinera>>() {});
				
				
				
				
				
			}
			conn.disconnect(); // Cerramos la conexión
		} catch (IOException e ) {
			e.printStackTrace();
		}
		
		return listado;
	}

	private static List<Gasolinera> generaGasolineras(JsonNode listaGasolinerasJson) {
		List<Gasolinera> listado = new ArrayList<Gasolinera>();
		
		for(JsonNode gasolineraJson: listaGasolinerasJson) {
			Gasolinera g = new Gasolinera();
			g.setDireccion(gasolineraJson.get("Dirección").asText());
			g.setLocalidad(gasolineraJson.get("Localidad").asText());
			g.setCompanhia(gasolineraJson.get("Rótulo").asText());
			JsonNode gasolina = gasolineraJson.get("Precio Gasolina 95 E5");
			double precioGasolina;
			if (gasolina.asText().equals("")) {
				precioGasolina = Double.MAX_VALUE;
			}else {
				precioGasolina = Double.parseDouble(gasolina.asText().replace(",", "."));
			}
			//double gasolina = Double.parseDouble(gasolineraJson.get("Precio Gasolina 95 E5").asText().replace(",", "."));
			g.setPrecioGasolina95E5(precioGasolina);
			//TODO:g.setPrecioGasolina95E5String(Peticiones.obtenTexto(precioGasolina));
			JsonNode gasoleo = gasolineraJson.get("Precio Gasoleo A");
			double precioGasoleo;
			if (gasoleo.asText().equals("")) {
				precioGasoleo = Double.MAX_VALUE;
			}else {
				precioGasoleo = Double.parseDouble(gasoleo.asText().replace(",", "."));
			}
			g.setPrecioGasoleoA(precioGasoleo);
			//TODO:g.setPrecioGasoleoAString(Peticiones.obtenTexto(precioGasoleo));
			
			listado.add(g);
		}
		
		return listado;
	}
	
	public static String obtenTexto(double precio) {
		NumberConversion cliente = new NumberConversion();
		
		NumberConversionSoapType stub = cliente.getNumberConversionSoap();
		
		return stub.numberToDollars(BigDecimal.valueOf(precio));
	}
}

