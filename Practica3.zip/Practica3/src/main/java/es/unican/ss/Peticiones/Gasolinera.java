package es.unican.ss.Peticiones;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Gasolinera {
	@JsonProperty("Dirección")
	private String direccion;
	@JsonProperty("Localidad")
	private String localidad;
	@JsonProperty("Rótulo")
	private String companhia;
	@JsonProperty("Precio Gasolina 95 E5")
	private double precioGasolina95E5;
	private String precioGasolina95E5String;
	@JsonProperty("Precio Gasoleo A")
	private double precioGasoleoA;
	private String precioGasoleoAString;
	
	
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getLocalidad() {
		return localidad;
	}
	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}
	public String getCompanhia() {
		return companhia;
	}
	public void setCompanhia(String companhia) {
		this.companhia = companhia;
	}
	public double getPrecioGasolina95E5() {
		return precioGasolina95E5;
	}
	public void setPrecioGasolina95E5(double precioGasolina95E5) {
		this.precioGasolina95E5 = precioGasolina95E5;
	}
	public String getPrecioGasolina95E5String() {
		return precioGasolina95E5String;
	}
	public void setPrecioGasolina95E5String(String precioGasolina95E5String) {
		this.precioGasolina95E5String = precioGasolina95E5String;
	}
	public double getPrecioGasoleoA() {
		return precioGasoleoA;
	}
	public void setPrecioGasoleoA(double precioGasoleoA) {
		this.precioGasoleoA = precioGasoleoA;
	}
	public String getPrecioGasoleoAString() {
		return precioGasoleoAString;
	}
	public void setPrecioGasoleoAString(String precioGasoleoAString) {
		this.precioGasoleoAString = precioGasoleoAString;
	}
	
	
}
