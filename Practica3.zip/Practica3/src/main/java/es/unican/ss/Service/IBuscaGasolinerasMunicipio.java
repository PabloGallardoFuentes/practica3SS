package es.unican.ss.Service;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import es.unican.ss.Peticiones.Gasolinera;

@WebService(targetNamespace = "http://www.unican.es/ss/Service/")
public interface IBuscaGasolinerasMunicipio {
	
	
	public List<Gasolinera> buscaGasolinerasDeGasolina (
			//@WebParam(name = "gasolina", targetNamespace = "http://www.unican.es/ss/Service/", partName = "params")
			String municipio) throws DatosNoDisponiblesException, MunicipioNoValidoException;
	
	
	public List<Gasolinera> buscaGasolinerasDeGasoleo(
			//@WebParam(name = "gasoleo", targetNamespace = "http://www.unican.es/ss/Service/", partName = "params")
			String municipio) throws DatosNoDisponiblesException, MunicipioNoValidoException;
}
