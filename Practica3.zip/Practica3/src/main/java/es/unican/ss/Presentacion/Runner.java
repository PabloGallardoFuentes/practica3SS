package es.unican.ss.Presentacion;

import java.util.List;

import es.unican.ss.Peticiones.Gasolinera;
import es.unican.ss.Peticiones.Peticiones;
import es.unican.ss.Service.BuscaGasolinerasMunicipio;

public class Runner {

	public static void main(String[] args) {
		String id = Peticiones.getIDMunicipio("Santander");
		System.out.println("Id:" + id);
		
		//Peticiones.getGasolinerasMunicipio(id);
		BuscaGasolinerasMunicipio buscador = new BuscaGasolinerasMunicipio();
		
		List<Gasolinera> mejores = buscador.buscaGasolinerasDeGasolina("Santander");
		for(Gasolinera g: mejores) {
			System.out.println("Gasolinera: "+g.getCompanhia()+"\t"+g.getPrecioGasolina95E5());
		}
	}

}
