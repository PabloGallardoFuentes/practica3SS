package es.unican.ss.Service;

import javax.xml.ws.WebFault;

@WebFault(name = "municipioNoValido", targetNamespace = "http://www.unican.es/ss/Service/")
public class MunicipioNoValidoException extends Exception{

}
